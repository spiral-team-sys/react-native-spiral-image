export declare function formatFileSize(bytes: number): string;
//# sourceMappingURL=formatFileSize.d.ts.map