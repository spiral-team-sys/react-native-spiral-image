import type { ImageSourcePropType } from 'react-native';
export declare function getCacheKey(source: ImageSourcePropType): string;
//# sourceMappingURL=getCacheKey.d.ts.map