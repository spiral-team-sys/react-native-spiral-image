import type { ImageSourcePropType } from 'react-native';
import type { SpiralProcessOptions } from '../types/index.js';
import type { CacheInfo, ResolveResult } from '../types/index.js';
export declare class CacheManager {
    /**
     * Generate cache key
     */
    static getKey(source: ImageSourcePropType): string;
    /**
     * Main image resolver
     */
    static resolve(source: ImageSourcePropType, options?: SpiralProcessOptions): Promise<ResolveResult>;
    /**
     * Cache information
     */
    static getInfo(source: ImageSourcePropType): Promise<CacheInfo>;
    /**
     * Check cache
     */
    static exists(source: ImageSourcePropType): Promise<boolean>;
    /**
     * Delete cache
     */
    static delete(source: ImageSourcePropType): Promise<boolean>;
    /**
     * Clear all cache
     */
    static clear(): Promise<void>;
}
//# sourceMappingURL=CacheManager.d.ts.map