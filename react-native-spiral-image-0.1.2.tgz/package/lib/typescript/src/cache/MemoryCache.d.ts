export declare class MemoryCache {
    private cache;
    get(key: string): string | undefined;
    has(key: string): boolean;
    set(key: string, value: string): void;
    remove(key: string): boolean;
    clear(): void;
    size(): number;
    keys(): string[];
}
//# sourceMappingURL=MemoryCache.d.ts.map