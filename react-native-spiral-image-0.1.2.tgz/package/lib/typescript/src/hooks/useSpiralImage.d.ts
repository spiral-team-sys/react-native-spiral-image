import type { ImageSourcePropType } from 'react-native';
import type { UseSpiralImageResult } from '../types/ImageTypes.js';
export declare function useSpiralImage(source: ImageSourcePropType): UseSpiralImageResult;
//# sourceMappingURL=useSpiralImage.d.ts.map