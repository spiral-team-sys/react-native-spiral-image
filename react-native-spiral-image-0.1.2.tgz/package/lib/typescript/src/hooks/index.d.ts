export * from './useSpiralImage.js';
//# sourceMappingURL=index.d.ts.map