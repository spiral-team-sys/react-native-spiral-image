import type { ImageSourcePropType } from 'react-native';
export declare class PendingRequests {
    private static requests;
    static get(uri: string): Promise<import("react-native").ImageSource> | undefined;
    static has(uri: string): boolean;
    static set(uri: string, promise: Promise<ImageSourcePropType>): void;
    static remove(uri: string): void;
}
//# sourceMappingURL=PendingRequests.d.ts.map