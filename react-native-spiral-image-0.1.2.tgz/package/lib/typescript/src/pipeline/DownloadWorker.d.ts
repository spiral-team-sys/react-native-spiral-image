import type { RequestTask, WorkerResult } from './types.js';
export declare class DownloadWorker {
    execute(task: RequestTask): Promise<WorkerResult>;
}
//# sourceMappingURL=DownloadWorker.d.ts.map