import type { ImageSourcePropType } from 'react-native';
export declare class RequestQueue {
    private static worker;
    static load(source: ImageSourcePropType): Promise<ImageSourcePropType>;
}
//# sourceMappingURL=RequestQueue.d.ts.map