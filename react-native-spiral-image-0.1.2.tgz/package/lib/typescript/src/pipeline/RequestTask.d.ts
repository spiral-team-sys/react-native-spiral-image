import type { RequestTask } from './types.js';
export declare function createRequestTask(uri: string): RequestTask;
//# sourceMappingURL=RequestTask.d.ts.map