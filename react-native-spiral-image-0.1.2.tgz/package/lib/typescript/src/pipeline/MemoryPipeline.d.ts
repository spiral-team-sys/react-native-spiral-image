export declare class MemoryPipeline {
    /**
     * Get cached file path
     */
    static get(key: string): string | undefined;
    /**
     * Check cache exists
     */
    static has(key: string): boolean;
    /**
     * Save cache path
     */
    static set(key: string, value: string): void;
    /**
     * Remove single cache
     */
    static remove(key: string): boolean;
    /**
     * Clear all memory cache
     */
    static clear(): void;
    /**
     * Cache size
     */
    static size(): number;
    /**
     * Cache keys
     */
    static keys(): string[];
}
//# sourceMappingURL=MemoryPipeline.d.ts.map