export declare class DiskPipeline {
    private static folder;
    /**
     * Ensure cache folder exists
     */
    private static ensureFolder;
    /**
     * Generate cache file path
     */
    static getPath(key: string): string;
    /**
     * Check disk cache exists
     */
    static has(key: string): Promise<boolean>;
    /**
     * Get cached file
     */
    static get(key: string): Promise<string | undefined>;
    /**
     * Save cache file
     */
    static save(key: string, sourcePath: string): Promise<string>;
    /**
     * Delete cache
     */
    static remove(key: string): Promise<boolean>;
    /**
     * Clear all disk cache
     */
    static clear(): Promise<void>;
}
//# sourceMappingURL=DiskPipeline.d.ts.map