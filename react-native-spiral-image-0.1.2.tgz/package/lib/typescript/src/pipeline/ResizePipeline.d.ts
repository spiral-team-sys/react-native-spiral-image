import type { ImageSourcePropType } from 'react-native';
export declare class ResizePipeline {
    static resize(source: ImageSourcePropType): Promise<ImageSourcePropType>;
}
//# sourceMappingURL=ResizePipeline.d.ts.map