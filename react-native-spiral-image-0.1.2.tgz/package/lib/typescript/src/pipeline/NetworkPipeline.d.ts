import type { ImageSourcePropType } from 'react-native';
export declare class NetworkPipeline {
    static download(source: ImageSourcePropType): Promise<ImageSourcePropType>;
}
//# sourceMappingURL=NetworkPipeline.d.ts.map