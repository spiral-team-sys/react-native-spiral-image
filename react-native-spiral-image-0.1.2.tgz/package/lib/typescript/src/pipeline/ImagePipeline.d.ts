import type { ImageSourcePropType } from 'react-native';
import type { SpiralProcessOptions } from '../types/index.js';
import type { CacheInfo, ResolveResult } from '../types/index.js';
export declare class ImagePipeline {
    /**
     * Main resolver
     *
     * Flow
     * Memory
     * ↓
     * Disk
     * ↓
     * Original
     * ↓
     * Network (future)
     */
    static resolve(source: ImageSourcePropType, options?: SpiralProcessOptions): Promise<ResolveResult>;
    /**
     * Memory
     */
    private static resolveMemory;
    /**
     * Disk
     */
    private static resolveDisk;
    /**
     * Original File
     */
    private static resolveOriginal;
    /**
     * Network (Phase 4)
     */
    private static resolveNetwork;
    /**
     * Cache information
     */
    static getInfo(source: ImageSourcePropType): Promise<CacheInfo>;
    static exists(source: ImageSourcePropType): Promise<boolean>;
    static delete(source: ImageSourcePropType): Promise<boolean>;
    static clear(): Promise<void>;
}
//# sourceMappingURL=ImagePipeline.d.ts.map