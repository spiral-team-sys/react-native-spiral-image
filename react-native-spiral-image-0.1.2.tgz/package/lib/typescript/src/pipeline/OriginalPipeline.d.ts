import type { ImageSourcePropType } from 'react-native';
export declare class OriginalPipeline {
    static isLocal(source: ImageSourcePropType): boolean;
    static getPath(source: ImageSourcePropType): string | undefined;
}
//# sourceMappingURL=OriginalPipeline.d.ts.map