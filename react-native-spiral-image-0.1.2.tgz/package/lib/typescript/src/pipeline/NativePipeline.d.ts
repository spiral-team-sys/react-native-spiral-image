import type { ImageSourcePropType } from 'react-native';
import { type SpiralProcessOptions } from 'react-native-spiral-image';
export declare class NativePipeline {
    /**
     * Process image using native Nitro module.
     *
     * Phase 2:
     * - passthrough (nếu chưa implement native)
     *
     * Phase 3:
     * - decode
     * - resize
     * - encode
     */
    static process(source: ImageSourcePropType, options?: SpiralProcessOptions): Promise<ImageSourcePropType>;
}
//# sourceMappingURL=NativePipeline.d.ts.map