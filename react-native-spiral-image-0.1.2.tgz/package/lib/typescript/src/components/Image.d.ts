import { type ImageProps, type ImageSourcePropType } from 'react-native';
import type { SpiralProcessOptions } from '../types/index.js';
export interface SpiralImageProps extends Omit<ImageProps, 'source'>, SpiralProcessOptions {
    source: ImageSourcePropType;
}
export declare function Image({ source, ...rest }: SpiralImageProps): import("react").JSX.Element;
export default Image;
//# sourceMappingURL=Image.d.ts.map