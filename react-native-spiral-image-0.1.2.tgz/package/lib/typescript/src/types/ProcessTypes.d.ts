import type { ImageFormat } from '../SpiralImage.nitro.js';
export interface SpiralProcessOptions {
    resize?: {
        width?: number;
        height?: number;
    };
    output?: {
        quality?: number;
        format?: ImageFormat;
        keepExif?: boolean;
    };
}
//# sourceMappingURL=ProcessTypes.d.ts.map