package com.margelo.nitro.spiralimage

import com.facebook.react.BaseReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.module.model.ReactModuleInfoProvider


class SpiralImagePackage : BaseReactPackage() {


    override fun getModule(
        name: String,
        reactContext: ReactApplicationContext
    ): NativeModule? {


        SpiralImageContext.initialize(
            reactContext
        )


        return null
    }



    override fun getReactModuleInfoProvider()
        : ReactModuleInfoProvider {

        return ReactModuleInfoProvider {

            HashMap()

        }

    }



    companion object {

        init {

            System.loadLibrary(
                "spiralimage"
            )

        }

    }

}